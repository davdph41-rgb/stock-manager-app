STOCK APP ANDROID - BUILD APK DARI HP ANDROID
============================================

Yang sudah ada di proyek ini:
- Fitur asli stok, tambah menu, transaksi, riwayat, dan laporan harian.
- Backup seluruh data ke file JSON.
- Pemulihan data dari file backup JSON.
- Ekspor laporan CSV.
- Ekspor workbook Excel XLSX (lembar Stok, Riwayat Transaksi, dan Laporan Harian).
- APK dapat dibangun lewat GitHub Actions tanpa komputer/Android Studio.

PENTING TENTANG FITUR ONLINE:
- Data aplikasi sekarang tersimpan lokal di perangkat (localStorage).
- Sinkronisasi antarperangkat dan login aman pengguna/admin BELUM aktif. Keduanya memerlukan backend online (misalnya Firebase) dan konfigurasi proyek/akun. Jangan menganggap login lokal sebagai keamanan sungguhan; jangan simpan data sensitif sebelum backend dikonfigurasi.
- Ekspor XLSX memuat pustaka SheetJS dari CDN, jadi perlu internet saat ekspor pertama/kapan pun cache tidak tersedia.
- File backup JSON berisi data stok dan riwayat. Simpan file itu dengan aman.

CARA MEMBUAT APK HANYA DENGAN HP ANDROID
========================================
1. Unduh ZIP proyek ini ke HP lalu ekstrak menggunakan aplikasi pengelola file.
2. Buka github.com di browser Android dan masuk/daftar akun GitHub.
3. Buat repository baru bernama StockApp-Android. Pilih Private jika kode ingin disimpan privat.
4. Upload semua ISI folder proyek (bukan folder induknya) ke repository. Pastikan file .github/workflows/build-apk.yml ikut terunggah. Di GitHub mobile, gunakan tampilan browser desktop jika upload folder sulit; upload file ZIP saja tidak cukup karena perlu file proyek diekstrak di repository.
5. Buka tab Actions pada repository. Jika diminta, aktifkan Actions.
6. Pilih workflow "Build Stock App APK" lalu tekan Run workflow. Tunggu sampai proses selesai (centang hijau).
7. Buka hasil run workflow dan cari bagian Artifacts. Unduh artifact "Stock-App-APK" (ZIP), lalu ekstrak di HP.
8. Ketuk app-debug.apk. Jika Android meminta izin, izinkan browser/pengelola file memasang aplikasi dari sumber tersebut, lalu tekan Install.

Catatan: APK yang dihasilkan adalah debug APK yang bisa dipasang untuk penggunaan pribadi. Untuk distribusi publik/Play Store, buat signing key dan rilis bertanda tangan.

CARA PAKAI BACKUP / RESTORE
===========================
- Tekan Backup Data (JSON), file akan disimpan ke folder Download.
- Untuk memulihkan, tekan Pulihkan Backup, pilih file Stock-App-Backup-....json, lalu konfirmasi. Data lokal saat ini akan diganti.
- Ekspor Excel menghasilkan file .xlsx di folder Download.

KONDISI SINKRONISASI DAN LOGIN
==============================
Untuk mengaktifkan sinkronisasi nyata antar-HP dan login Admin/Pengguna yang aman, perlu dibuat dan dikonfigurasi backend (mis. Firebase Authentication + Firestore/Realtime Database), termasuk aturan akses admin/pengguna. Ini tidak bisa dibuat aman hanya dengan menyimpan kredensial di file HTML/JavaScript. Proyek ini belum mengirim data ke server dan tidak membuat akun online.
